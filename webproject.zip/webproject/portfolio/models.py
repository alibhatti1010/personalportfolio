from django.db import models


class Education(models.Model):
    degree = models.CharField(max_length=255)
    institution = models.CharField(max_length=255)
    year = models.CharField(max_length=4)
    link = models.URLField(max_length=200, blank=True)


class Experience(models.Model):
    title = models.CharField(max_length=255)
    company = models.CharField(max_length=255)
    duration = models.CharField(max_length=255)
    description = models.TextField()


class Skill(models.Model):
    category = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    proficiency = models.IntegerField()


class Product(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    link = models.URLField(max_length=200, blank=True)


class Contact(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField()
    message = models.TextField()
