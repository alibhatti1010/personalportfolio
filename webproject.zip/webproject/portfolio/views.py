from django.shortcuts import render, redirect
from .models import Education, Experience, Skill, Product, Contact


def home(request):
    educations = Education.objects.all()
    experiences = Experience.objects.all()
    skills = Skill.objects.all()
    products = Product.objects.all()
    context = {
        'educations': educations,
        'experiences': experiences,
        'skills': skills,
        'products': products,
    }
    return render(request, 'portfolio/home.html', context)


def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        # Debugging statements
        print(f"Name: {name}, Email: {email}, Message: {message}")

        if name and email and message:
            try:
                Contact.objects.create(name=name, email=email, message=message)
                # Redirect to a success page or add success message here
                return redirect('home')  # Example redirection
            except Exception as e:
                print(f"Error: {e}")
                # Handle the error, add error message or logging here
        else:
            print("Form fields are missing")
    return render(request, 'contact.html')
